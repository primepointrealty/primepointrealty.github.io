# PrimePoint Realty — Premium Corporate Website

## Files
- `index.html` — complete homepage
- `style.css` — responsive Premium Corporate design
- `script.js` — mobile navigation, scroll reveal, active navigation and WhatsApp enquiry form
- `assets/primepoint-hero.jpeg` — supplied PrimePoint Realty hero image

## Deploy on GitHub Pages
1. Replace the existing `index.html` with this `index.html`.
2. Upload `style.css` and `script.js` beside it.
3. Create an `assets` folder and upload `primepoint-hero.jpeg` inside it.
4. Commit/push the files to the repository.
5. GitHub Pages will publish the updated site.

The WhatsApp enquiry number is configured as +91 88559 24593 and the email as primepointrealty3@gmail.com.
